# DICIONARIO DE SINONIMOS E TERMOS - IX RADIOLOGIA

SEMPRE consultar esta secao ANTES de dizer "nao fazemos"

## SINONIMOS DE EXAMES

| Cliente disse | Significa | ID Exame |
|---------------|-----------|----------|
| Raio-X da mao | Carpal | 5 |
| Raio-X de punho | Carpal | 5 |
| Raio-X carpal | Carpal | 5 |
| Documentacao | Documentacao Ortodontica | 1 |
| Modelo | Modelo Ortodontico | 1B |
| Raio-X panoramico | Panoramica | 2 |
| Infraoral / Intraoral | Escaneamento Intraoral | 10 |
| ATM / Raio-X de ATM / Radiografia ATM | Radiografia de ATM | 11 |
| CBCT / Cone Beam | Tomografia Computadorizada | 3 |

## SINONIMOS DE CONVENIOS

| Cliente disse | Significa |
|---------------|-----------|
| Medial / Medial Saude | AMIL |
| Santander / Santander Dental | AMIL |
| Bradesco Dental / BB Dental | ODONTOPREV |
| Privian | ODONTOPREV |
| Prevident | REDE BRAZIL DENTAL |
| Bio Oral | REDE BRAZIL DENTAL |
| Pernambucanas Dental | REDE BRAZIL DENTAL |
| Wdental / W Dental | REDE BRAZIL DENTAL |
| Dental Seg / DentalSeg | REDE BRAZIL DENTAL |
| OdontoSeg | REDE BRAZIL DENTAL |
| Pefisa | REDE BRAZIL DENTAL |
| Quality Dental | REDE BRAZIL DENTAL |
| Pro Saude / Pro Saude | REDE BRAZIL DENTAL |
| Lis Dental | REDE BRAZIL DENTAL |
| Presb | REDE BRAZIL DENTAL |
| CAEDU | SEMPRE ODONTO |
| Prodental / Prodental Brasil | PRODENTAL BRASIL |
| Bradesco Saude | BRADESCO SAUDE (diferente de Bradesco Dental/Odontoprev) |

## TERMOS AMBIGUOS - PERGUNTAR ANTES DE RESPONDER

| Cliente disse | Acao |
|---------------|------|
| Raio-X / Chapa da boca / Exame de imagem | NAO assumir - perguntar qual exame especifico |
| De todos os dentes | Perguntar: "Voce teria o nome do exame que o dentista indicou?" |
| Para tirar um dente | Perguntar: "Voce sabe o nome do exame ou tem a solicitacao em maos?" |
| Odonto (sozinho) | Perguntar qual convenio especifico (Odontoprev? Porto Seguro Odonto?) |

## IMPORTANTE - NOMENCLATURA

- NUNCA dizer "CBCT" para o cliente
- SEMPRE usar "Tomografia Computadorizada"
- So mencionar "CBCT" se CLIENTE usar primeiro
